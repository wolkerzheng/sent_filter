#coding=utf-8
import os
import sys
import nltk
import cPickle as pkl
import numpy as np
from min_edit_distance import Med
class Vector_op():
    '''
    word to vector 中的向量转化的相关操作
    '''
    def __init__(self):
        self.w2v_file = 'E:\\Graduation_design_data\\w2v\\GoogleNews-vectors-negative300.bin'
        self.glove_file = 'E:\\Graduation_design_data\\w2v\\glove.840B.300d.txt'
        return

    def load_bin_vec(self, vocab):
        '''
        加载300x1 word vecs Google (Mikolov) word2vec，从中提取vocab中单词的词向量
        '''
        word_vecs = {}
        with open(self.w2v_file, "rb") as f:
            header = f.readline()
            vocab_size, layer1_size = map(int, header.split())
            binary_len = np.dtype('float32').itemsize * layer1_size
            for line in xrange(vocab_size):
                word = []
                while True:
                    ch = f.read(1)
                    if ch == ' ':
                        word = ''.join(word)
                        break
                    if ch != '\n':
                        word.append(ch)
                if word in vocab:
                    word_vecs[word] = np.fromstring(f.read(binary_len), dtype='float32')
                else:
                    f.read(binary_len)
        return word_vecs

    def load_glove_vec(self, vocab):
        '''
        加载300x1 word vecs glove.840B，从中提取vocab中单词的词向量
        '''
        word_vecs = {}
        with open(self.glove_file, 'rb') as f:
            for line in f:
                line_split = line.strip().split(" ")
                vec = np.array(line_split[1:], dtype=float)
                word = line_split[0]
                if word in vocab:
                    word_vecs[word] = vec

        return word_vecs

    def add_unknown_words(self, word_vecs, vocab, min_df=1, k=300):
        '''
        未登录词处理，对于出现次数大于min_df的单词，选择0.25阈值确保和预训练的值一致
        '''
        for word in vocab:
            if word not in word_vecs and vocab[word] >= min_df:
                word_vecs[word] = np.random.uniform(-0.25, 0.25, k)

        return word_vecs

    def glove_med_unknow(self,unk_word):
        '''
        从glove词向量中加载未登录词词向量
        '''
        unk_vec = {}
        with open(self.glove_file, 'rb') as f:
            for line in f:
                line_split = line.strip().split(" ")
                vec = np.array(line_split[1:], dtype=float)
                med_word = line_split[0]

                if med_word in unk_word:
                    un_word = unk_word[med_word]
                    unk_vec[un_word] = vec

        return unk_vec

    def add_unknown_words_Med(self, word_vecs, vocab):
        '''
        根据最小编辑距离，赋值为最小编辑距离单词的词向量
        '''
        med, unk_word = Med(), {}
        for word in vocab:
            if word not in word_vecs:
                rank = med.get_ranked_list(word)
                if rank:
                    med_w = rank[0][0]
                    unk_word[med_w] = word
                else:
                    continue
        if unk_word:
            unk_vec = self.glove_med_unknow(unk_word)
            if unk_vec:
                for un_word, vec in unk_vec.items():
                    word_vecs[un_word] = vec

        return word_vecs

    def add_unknown_words_ave2(self):
        return

    def get_W(self, word_vecs, k=300):
        '''
        获得词向量矩阵和单词索引矩阵，其中w[i]为下标为i的单词的词向量
        '''
        vocab_size = len(word_vecs)
        word_idx_map = dict()
        W = np.zeros(shape=(vocab_size + 1, k), dtype='float32')
        W[0] = np.zeros(k, dtype='float32')
        i = 1
        for word in word_vecs:
            W[i] = word_vecs[word]
            word_idx_map[word] = i
            i += 1
        return W, word_idx_map

    def get_idx_from_sent(self, sent, word_idx_map):
        """
        将句子单词列表转换成索引列表
        """
        x = []
        #words = sent.split()
        words = nltk.word_tokenize(sent)
        print words
        for word in words:
            if word in word_idx_map:
                x.append(word_idx_map[word])
            else:
                x.append(0)  # 未登录词用下标0表示
        return x

    def cos(self,vector1, vector2):
        dot_product = 0.0
        normA = 0.0
        normB = 0.0
        for a, b in zip(vector1, vector2):
            dot_product += a * b
            normA += a ** 2
            normB += b ** 2
        if normA == 0.0 or normB == 0.0:
            return None
        else:
            return dot_product / ((normA * normB) ** 0.5)

if __name__ == '__main__':
    v_op = Vector_op()
    vocab = {'good':0,'nice':1,'writong':2,'writing':4}
    word_vecs = v_op.load_glove_vec(vocab)
    word_vecs = v_op.add_unknown_words_Med(word_vecs,vocab)
    word_vecs = v_op.add_unknown_words(word_vecs,vocab)

    v1 = word_vecs['good']
    v2 = word_vecs['nice']
    v3 = word_vecs['writong']
    v4 = word_vecs['writing']
    print v_op.cos(v1,v2)
    print v_op.cos(v3,v4)