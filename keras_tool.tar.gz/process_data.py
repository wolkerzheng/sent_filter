#coding=utf-8
import numpy as np
import cPickle as pkl
from collections import defaultdict
import sys,re
import pandas as pd
import warnings
from vector_op import Vector_op
warnings.filterwarnings("ignore")
sys.path.append("..")
from Data_Preprocess import Data_preprocess
np.random.seed(1337)  # 程序的复现性

class Spam_process():
    '''
    keras deeplearn工具对spam数据集进行数据预处理操作
    '''
    def __init__(self,data_flag = 'Pos'):
        self.data_flag = data_flag
        self.pkl_path = '.\\data_pkl\\'+ self.data_flag +'_true_spam.pkl'
        self.w2v_file = 'E:\\Graduation_design_data\\w2v\\GoogleNews-vectors-negative300.bin'
        self.glove_file = 'E:\\Graduation_design_data\\w2v\\glove.840B.300d.txt'
        self.data_pre = Data_preprocess()
        self.v_op = Vector_op()
        return

    def get_ott_data(self):
        '''
        根据flag获得ott语料
        '''
        ott_data = self.data_pre.read_ott_data_sklearn(self.data_flag)
        X_entire, y_entire = ott_data.data, ott_data.target
        return X_entire, y_entire

    def build_data_cv(self, X_entire, cv=5,clean_string = True):
        '''
        加载数据集，并且将数据集分割为5fold
        :param X_entire: 数据集
        :param cv: k-fold的层数
        :param clean_string: 是否进行数据清洗
        :return: 封装的评论集，语料词典
        '''
        revs = []
        spam_file = X_entire[:len(X_entire)/2]
        truthful_file = X_entire[len(X_entire)/2:]

        vocab = defaultdict(float)

        for line in truthful_file:
            rev = []
            rev.append(line.strip())
            if clean_string:
                orig_rev = self.clean_str(" ".join(rev))
            else:
                orig_rev = " ".join(rev).lower()
            words = set(orig_rev.split())
            for word in words:
                vocab[word] += 1
            datum = {"y": 1,
                    "text": orig_rev,
                    "num_words": len(orig_rev.split()),
                    "split": np.random.randint(0, cv)}
            revs.append(datum)

        for line in spam_file:
            rev = []
            rev.append(line.strip())
            if clean_string:
                orig_rev = self.clean_str(" ".join(rev))
            else:
                orig_rev = " ".join(rev).lower()
            words = set(orig_rev.split())
            for word in words:
                vocab[word] += 1
            datum = {"y": 0,
                    "text": orig_rev,
                    "num_words": len(orig_rev.split()),
                    "split": np.random.randint(0, cv)}
            revs.append(datum)

        return revs, vocab

    def keras_pickle_data(self,):
        '''
        对评论语料集进行封装
        :param flag:封装的语料的类别
        :return:
        '''
        X_entire, y_entire = self.get_ott_data()
        print "loading data...",

        revs, vocab = self.build_data_cv(X_entire, cv=5,)
        max_l = np.max(pd.DataFrame(revs)["num_words"])
        print "data loaded!"
        print "number of sentences: " + str(len(revs))
        print "vocab size: " + str(len(vocab))
        print "max sentence length: " + str(max_l)
        print "loading word2vec vectors...",
        w2v = self.v_op.load_bin_vec(vocab)

        print "word2vec loaded!"
        print "num words already in word2vec: " + str(len(w2v))
        w2v = self.v_op.add_unknown_words(w2v, vocab)
        W, word_idx_map = self.v_op.get_W(w2v)

        pkl.dump([revs, W, word_idx_map, vocab], open(self.pkl_path, "wb"))
        print "dataset created!"

        return

    def make_idx_data_cv(self,revs, word_idx_map, cv):
        """
        将评论的句子转化成2d的矩阵
        :param revs: 句子的评论列表
        :param word_idx_map: 单词与下标映射词典
        :param cv: 取用第cv个k_fold
        :return: 训练集和测试集
        """
        X_train, y_train, X_test, y_test = [],[],[],[]
        for rev in revs:
            sent = self.get_idx_from_sent(rev["text"], word_idx_map)
            if rev["split"] == cv:
                X_test.append(sent)
                y_test.append(rev["y"])
            else:
                X_train.append(sent)
                y_train.append(rev["y"])

        X_train = np.array(X_train, dtype="object")
        y_train = np.array(y_train, dtype="int")
        X_test = np.array(X_test, dtype="object")
        y_test = np.array(y_test, dtype="int")

        return (X_train,y_train),(X_test, y_test)

    def get_onecv_data(self,revs,word_idx_map,cv = 0,shuffle = True):
        '''
        根据cv的值抽取出pkl中的文件，得到训练集和测试集，对数据进行洗牌
        '''
        (X_train, y_train), (X_test, y_test) = self.make_idx_data_cv(revs, word_idx_map, cv)
        if shuffle:
            np.random.seed(42)
            np.random.shuffle(X_train)
            np.random.seed(42)
            np.random.shuffle(y_train)

            np.random.seed(42 * 2)
            np.random.shuffle(X_test)
            np.random.seed(42 * 2)
            np.random.shuffle(y_test)

        return (X_train, y_train), (X_test, y_test)

    def get_pkl_data(self):
        '''
        根据flag抽取出pkl的数据
        :return:
        '''
        print "loading data...",
        x = pkl.load(open(self.pkl_path, "rb"))
        revs, W, word_idx_map, vocab = x[0], x[1], x[2], x[3]
        print "data loaded!"
        return (revs, W, word_idx_map, vocab)

    def clean_str(self,string):
        """
        对字符串进行预处理，降噪
        """
        string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
        string = re.sub(r"\'s", " 's", string)
        string = re.sub(r"\'ve", " 've", string)
        string = re.sub(r"n\'t", " n\'t", string)
        string = re.sub(r"\'re", " 're", string)
        string = re.sub(r"\'d", " 'd", string)
        string = re.sub(r"\'ll", " 'll", string)
        string = re.sub(r",", " , ", string)
        string = re.sub(r"!", " ! ", string)
        string = re.sub(r"\(", " ( ", string)
        string = re.sub(r"\)", " ) ", string)
        string = re.sub(r"\?", " ? ", string)
        string = re.sub(r"\s{2,}", " ", string)

        return string.strip()

if __name__ == "__main__":

    keras_p = Spam_process(data_flag= 'Neg')
    (X_train, y_train), (X_test, y_test) = keras_p.get_onecv_data()