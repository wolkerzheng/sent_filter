#coding=utf-8
import numpy as np
np.random.seed(2017)
from keras.layers import Input,Dense, Dropout, Activation, Embedding,merge
from keras.layers import LSTM, GRU ,Bidirectional,Merge,Flatten,TimeDistributed,SimpleRNN
from keras.preprocessing import sequence
from keras.models import Model,load_model
from keras.layers import Dense, Dropout, Activation, Embedding,Flatten
from keras.layers import Convolution1D, MaxPooling1D
from keras.callbacks import Callback,ModelCheckpoint
from sklearn.metrics import precision_recall_fscore_support
from Attention import Attention
from AttentionWithContext import AttentionWithContext

class LossHistory(Callback):
    def on_train_begin(self, logs={}):
        self.losses = []

    def on_batch_end(self, batch, logs={}):
        self.losses.append(logs.get('loss'))

class Cnn_att():
    '''
    cnn模型用来文本分类，cnn-lstm(attention)
    '''
    def __init__(self,maxlen,vb_size,pre_w2v):
        self.b_size = 32
        self.nb_epoch = 30
        self.units = 300
        self.drop = 0.35
        self.nb_filter = 300
        self.filter_hs=[1,2,3,4]
        self.maxlen = maxlen
        self.vb_size = vb_size
        self.pre_w2v = pre_w2v
        self.bi,self.att,self.att_con,self.lstm = None,None,None,None
        return

    def get_embedding(self,pre_train = True):
        '''
        产生embedding层词向量
        '''
        if pre_train:
            embed = Embedding(self.vb_size, 300, dropout=self.drop, weights=[self.pre_w2v], input_length=self.maxlen,trainable=True)
        else:
            embed = Embedding(self.vb_size, 300, dropout=self.drop, input_length=self.maxlen, trainable=True)
        return embed

    def get_encoder_param(self,bi = True,lstm = True,att = False,att_con = False):
        '''
        获得encoder的参数，（lstm,gru,bi,att）,产生文件名
        '''
        B = '_Bi' if bi else ''
        A = '_Att' if att else ''
        AC = '_AttCon' if att_con else ''
        L = '_lstm' if lstm else ''
        save_to = 'Co_cnn' + L + B + A + AC
        self.bi, self.lstm , self.att, self.att_con = bi, lstm, att, att_con
        return save_to

    def get_encoder(self,):
        '''
        获得相应的encoder，以及是否为双向的
        '''
        enco = None
        if self.att or self.att_con:
            enco = LSTM(self.units,return_sequences=True)
        else:
            enco = LSTM(self.units,dropout_W=self.drop, dropout_U=self.drop )
        if self.bi:
            enco = Bidirectional(enco,merge_mode='ave')

        return enco

    def creat_cnn_model(self,):
        '''
        生成卷积模型，filter_hs为卷积窗口的大小
        '''
        merge_model = []
        embed = self.get_embedding()
        con_input = Input(shape=(self.maxlen,), dtype='int32', name='model_input')
        emb = embed(con_input)

        for filter_h in self.filter_hs:
            con = Convolution1D(nb_filter=self.nb_filter, filter_length=filter_h, border_mode='valid', activation='relu')(emb)
            x = MaxPooling1D(pool_length=con._keras_shape[1])(con)
            x = Flatten()(x)
            merge_model.append(x)

        merge_x = merge(merge_model, mode='concat')
        x = Dense(128, activation='relu')(merge_x)
        x = Dense(128, activation='relu')(x)
        x = Dense(128, activation='relu')(x)
        x = Dropout(0.35)(x)
        model_output = Dense(1, activation='sigmoid', name='model_output')(x)
        model = Model(con_input, model_output)
        model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
        return model

    def creat_cnn_lstm_model(self,):
        '''
        生成卷积模型，和lstm相结合，filter_hs为卷积窗口的大小。
        可选attention和att_context两种注意力模型。
        '''
        assert not self.att or not self.att_con
        merge_model = []
        embed = self.get_embedding()

        con_input = Input(shape=(self.maxlen,), dtype='int32', name='model_input')
        emb = embed(con_input)
        encoder = self.get_encoder()
        for filter_h in self.filter_hs:
            con = Convolution1D(nb_filter=self.nb_filter, filter_length=filter_h, border_mode='valid', activation='relu',)(emb)
            x = MaxPooling1D(pool_length=con._keras_shape[1])(con)
            lstm_out = encoder(x)
            if self.att:
                lstm_out = Attention()(lstm_out)
            if self.att_con:
                lstm_out = AttentionWithContext()(lstm_out)
            merge_model.append(lstm_out)

        merge_x = merge(merge_model, mode='concat')
        x = Dense(128, activation='relu')(merge_x)
        x = Dense(128, activation='relu')(x)
        x = Dropout(0.35)(x)
        model_output = Dense(1, activation='sigmoid', name='model_output')(x)
        model = Model(con_input, model_output)
        model.compile(optimizer='rmsprop', loss='binary_crossentropy', metrics=['accuracy'])
        return model

    def train_model(self,train_data,test_data,model,file_name):
        '''
        训练相应的模型
        '''
        checkpointer = ModelCheckpoint(filepath=file_name, monitor='val_acc', verbose=1,
                                       save_best_only=True,save_weights_only=False)
        history = LossHistory()
        X_train, y_train = train_data
        X_test, y_test = test_data
        model.fit(X_train, y_train,
                  batch_size=self.b_size,
                  nb_epoch=self.nb_epoch,
                  validation_data=(X_test, y_test),
                  verbose=1,
                  callbacks=[checkpointer, history]
                  )
        return

    def perf_model(self,test_data,file_name,):
        '''
        在测试集上评估模型的表现
        '''
        X_test, y_test = test_data
        if self.att_con:
            model = load_model(file_name,custom_objects={'AttentionWithContext': AttentionWithContext})
        elif self.att:
            model = load_model(file_name, custom_objects={'Attention': Attention})
        else:
            model = load_model(file_name)
        _, acc = model.evaluate(X_test, y_test, batch_size=self.b_size)
        print 'Test accuracy:', acc

        sig_y = model.predict(X_test,batch_size=self.b_size, verbose=0)
        pred_y =[(i[0] > 0.5).astype('int32') for i in sig_y ]

        PRF = precision_recall_fscore_support(y_test, pred_y, average=None, labels=[0, 1])
        return acc,PRF

if __name__ == '__main__':
    pass