#coding=utf-8
import os,sys
import numpy as np
import cPickle as pkl
from collections import defaultdict
import sys,re,random
import pandas as pd
import warnings
from vector_op import Vector_op
from process_data import Spam_process
warnings.filterwarnings("ignore")
sys.path.append("..")
from Data_Preprocess import Data_preprocess
np.random.seed(1337)  # 程序的复现性
real_path = os.path.dirname(os.path.realpath(__file__))
class Spam_process_co():
    '''
    keras deeplearn工具对spam和协同训练的数据集进行预处理
    '''
    def __init__(self,data_flag = 'Pos'):

        self.data_flag = data_flag
        self.cow_pkl_path = real_path + '\\data_pkl\\'+ self.data_flag +'_cow_true_spam.pkl'
        self.cog_pkl_path = real_path + '\\data_pkl\\' + self.data_flag + '_cog_true_spam.pkl'
        self.w2v_file = 'E:\\Graduation_design_data\\w2v\\GoogleNews-vectors-negative300.bin'
        self.glove_file = 'E:\\Graduation_design_data\\w2v\\glove.840B.300d.txt'
        self.data_pre = Data_preprocess()
        self.spam_p = Spam_process(data_flag=self.data_flag)
        self.v_op = Vector_op()
        return

    def get_co_data(self):
        '''
        根据flag获得co语料
        '''
        random.seed(42)
        co_data = self.data_pre.read_co_data_sklearn(self.data_flag)
        X_entire, y_entire = co_data.data, co_data.target
        spam_review = X_entire[:2799]
        truth_review = X_entire[2799:]
        truth_sub = random.sample(truth_review,2799)
        return spam_review,truth_sub

    def build_co_data(self,co_data,clean_str = True):
        '''
        加载co数据集，统计语料和词汇量
        '''
        revs = []
        vocab = defaultdict(float)
        s_revs,t_revs = co_data
        for line in t_revs:
            rev = line.strip()
            orig_rev = self.clean_str(rev) if clean_str else rev
            words = set(orig_rev.split())
            for word in words:
                vocab[word] += 1
            datum = {
                    "y": 1,"text": orig_rev,"num_words": len(orig_rev.split())
                    }
            revs.append(datum)

        for line in s_revs:
            rev = line.strip()
            orig_rev = self.clean_str(rev) if clean_str else rev
            words = set(orig_rev.split())
            for word in words:
                vocab[word] += 1
            datum = {
                    "y": 0,"text": orig_rev,"num_words": len(orig_rev.split()),
                    }
            revs.append(datum)

        return revs, vocab

    def pkl_ottvco_data(self,glove = True):
        '''
        将读取的ott语料和co语料(协同训练)进行合并
        '''
        print "loading ott data...",
        ott_data = self.spam_p.get_ott_data()
        ott_revs, ott_vocab = self.spam_p.build_data_cv(ott_data[0], cv=5, )
        print "ott data loaded!"

        print "loading co data...",
        co_data = self.get_co_data()
        co_revs, co_vocab = self.build_co_data(co_data)
        print "co data loaded!"

        vocab_con = dict(ott_vocab, **co_vocab)
        revs_con = ott_revs + co_revs

        print "number of sentences: " + str(len(revs_con))
        print "vocab size: " + str(len(vocab_con))

        print "loading word2vec vectors..."
        if glove:
            w2v = self.v_op.load_glove_vec(vocab_con)
            print "num words already in glove: " + str(len(w2v))
            w2v = self.v_op.add_unknown_words_Med(w2v, vocab_con)
            w2v = self.v_op.add_unknown_words(w2v, vocab_con)
        else:
            w2v = self.v_op.load_bin_vec(vocab_con)
            print "num words already in word2vec: " + str(len(w2v))
            w2v = self.v_op.add_unknown_words(w2v, vocab_con)

        W, word_idx_map = self.v_op.get_W(w2v)
        w2v_file = self.cog_pkl_path if glove else self.cow_pkl_path
        pkl.dump([ott_revs, co_revs, W, word_idx_map, vocab_con], open(w2v_file, "wb"))
        print "dataset created!"

        return

    def get_onecv_data(self, ott_revs,co_revs, word_idx_map, cv=0, shuffle=True):
        '''
        根据cv的值抽取出pkl中的文件，得到训练集和测试集
        '''
        (X_train, y_train), (X_test, y_test) = self.make_idx_data_cv(ott_revs,co_revs, word_idx_map, cv)

        if shuffle:
            np.random.seed(42)
            np.random.shuffle(X_train)
            np.random.seed(42)
            np.random.shuffle(y_train)

            np.random.seed(42 * 2)
            np.random.shuffle(X_test)
            np.random.seed(42 * 2)
            np.random.shuffle(y_test)

        return (X_train, y_train), (X_test, y_test)

    def make_idx_data_cv(self, ott_revs,co_revs, word_idx_map, cv):
        """
        得到相应的cv评论作为测试集，非cv作为训练集
        """
        X_train, y_train, X_test, y_test = [], [], [], []
        for rev in ott_revs:
            sent = self.v_op.get_idx_from_sent(rev["text"], word_idx_map)
            if rev["split"] == cv:
                X_test.append(sent)
                y_test.append(rev["y"])
            else:
                X_train.append(sent)
                y_train.append(rev["y"])

        for rev in co_revs:
            sent = self.v_op.get_idx_from_sent(rev["text"], word_idx_map)
            X_train.append(sent)
            y_train.append(rev["y"])

        X_train = np.array(X_train, dtype="object")
        y_train = np.array(y_train, dtype="int")

        X_test = np.array(X_test, dtype="object")
        y_test = np.array(y_test, dtype="int")

        return (X_train, y_train), (X_test, y_test)

    def get_pkl_data(self,glove=True):
        '''
        根据flag抽取出pkl的数据
        '''
        print "loading data...",
        if glove:
            file_path = self.cog_pkl_path
        else:
            file_path = self.cow_pkl_path
        ott_revs, co_revs, W, word_idx_map, vocab_con = pkl.load(open(file_path, "rb"))
        print "data loaded!"

        return ott_revs, co_revs, W, word_idx_map, vocab_con

    def print_save_result(self,accuracy, spam_prf, true_prf,file_name):
        '''
        打印模型的输出结果
        '''
        save2 = real_path + '\\model_result\\' + file_name
        ace_spam_prf, ave_true_prf = np.mean(np.array(spam_prf), axis=0), np.mean(np.array(true_prf), axis=0)
        print 'Average acc:', str(np.mean(accuracy))
        s_prf = 'Spam_data P:%.3f R:%.3f F:%.3f' % (ace_spam_prf[0], ace_spam_prf[1], ace_spam_prf[2])
        t_prf = 'Truthful_data P:%.3f R:%.3f F:%.3f' % (ave_true_prf[0], ave_true_prf[1], ave_true_prf[2])
        print s_prf
        print t_prf
        with open(save2,'w') as f:
            f.write('Average acc: ' + str(np.mean(accuracy)) + '\n')
            f.write(s_prf + '\n')
            f.write(t_prf)
        return

    def clean_str(self, string):
        """
        对字符串进行预处理，降噪
        """
        string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
        string = re.sub(r"\'s", " 's", string)
        string = re.sub(r"\'ve", " 've", string)
        string = re.sub(r"n\'t", " n\'t", string)
        string = re.sub(r"\'re", " 're", string)
        string = re.sub(r"\'d", " 'd", string)
        string = re.sub(r"\'ll", " 'll", string)
        string = re.sub(r",", " , ", string)
        string = re.sub(r"!", " ! ", string)
        string = re.sub(r"\(", " ( ", string)
        string = re.sub(r"\)", " ) ", string)
        string = re.sub(r"\?", " ? ", string)
        string = re.sub(r"\s{2,}", " ", string)

        return string.strip()

if __name__ == "__main__":
    spam_pco = Spam_process_co(data_flag='Pos')
    ott_revs, co_revs, W, word_idx_map, vocab_con = spam_pco.get_pkl_data(glove = True)
    print len(ott_revs),len(co_revs),len(vocab_con)
    (X_train, y_train), (X_test, y_test) = spam_pco.get_onecv_data(ott_revs,co_revs, word_idx_map,3)
    print y_train.shape
    print y_test.shape
    print y_test