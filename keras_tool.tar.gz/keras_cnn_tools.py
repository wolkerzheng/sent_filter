#coding=utf-8
import numpy as np
np.random.seed(2017)
import theano
from sklearn.svm import SVC
from sklearn import metrics
from process_data import Spam_process
from sklearn.ensemble import RandomForestClassifier
from keras.preprocessing import sequence
from keras.models import Model,Sequential,load_model,model_from_json
from keras.layers import Dense, Dropout, Activation, Embedding,Flatten
from keras.layers import LSTM, GRU ,Merge,Bidirectional
from keras.layers import Convolution1D, MaxPooling1D
from keras.callbacks import Callback,ModelCheckpoint
from sklearn.metrics import precision_recall_fscore_support
#pos评论: vocabulary size 5605 + 1
#neg评论：vocabulary size 7679 + 1
'''
cnn结果
Average acc: 0.911668699505
Spam_data P:0.904 R:0.920 F:0.912
Truthful_data P:0.921 R:0.899 F:0.910
'''
'''
cnn_lstm结果
Average acc: 0.908927836273
Spam_data P:0.915 R:0.901 F:0.908
Truthful_data P:0.902 R:0.915 F:0.909
'''
'''
cnn_svm结果
Average acc: 0.906754227815
Spam_data P:0.904 R:0.910 F:0.907
Truthful_data P:0.908 R:0.904 F:0.906
'''
class LossHistory(Callback):
    def on_train_begin(self, logs={}):
        self.losses = []

    def on_batch_end(self, batch, logs={}):
        self.losses.append(logs.get('loss'))

def svc(X_train, y_train, X_test, y_test):
    '''
    训练svm模型，获得模型结果
    :param X_train: 训练集
    :param y_train: 训练集标签
    :param X_test: 测试集
    :param y_test: 测试集标签
    :return: 模型的结果
    '''
    print("Start training SVM...")
    svcClf = SVC(C=1.0, kernel="rbf")
    svcClf.fit(X_train, y_train)
    y_pred = svcClf.predict(X_test)
    acc = metrics.accuracy_score(y_test, y_pred)
    print 'Test accuracy:', acc
    PRF = precision_recall_fscore_support(y_test, y_pred, average=None, labels=[0, 1])
    return acc,PRF


def rf(X_train, y_train, X_test, y_test):
    '''
    训练RF模型，获得模型结果
    :param X_train: 训练集
    :param y_train: 训练集标签
    :param X_test: 测试集
    :param y_test: 测试集标签
    :return: 模型的结果
    '''
    print("Start training Random Forest...")
    rfClf = RandomForestClassifier(n_estimators=400, criterion='gini')
    rfClf.fit(X_train, y_train)
    y_pred = rfClf.predict(X_test)
    acc = metrics.accuracy_score(y_test, y_pred)
    print 'Test accuracy:', acc
    PRF = precision_recall_fscore_support(y_test, y_pred, average=None, labels=[0, 1])
    return acc, PRF

def create_cnn_model(emb,filter_hs=[1,2,3,4]):
    '''
    返回创建的cnn模型
    :param emb: 词向量层
    :param filter_hs: 卷积窗口的大小
    :return: 创建好的模型
    '''
    print 'Build cnn model...'
    merge_model = []

    for filter_h in filter_hs:
        model = Sequential()
        model.add(emb)
        model.add(Convolution1D(nb_filter=300, filter_length=filter_h, border_mode='valid', activation='relu'))
        model.add(MaxPooling1D(pool_length=model.output_shape[1]))
        model.add(Flatten())
        merge_model.append(model)

    merged = Merge(merge_model, mode='concat',name='merge')
    model = Sequential()
    model.add(merged)
    model.add(Dense(700, activation='tanh',name='fea_map'))
    model.add(Dropout(0.5))
    model.add(Dense(1, activation='sigmoid'))

    model.compile(loss='binary_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])
    return model

def create_cnn_lstm_model(emb,filter_hs=[1,2,3,4],encoder='gru'):
    '''
    返回创建的cnn_lstm模型
    :param emb: 词向量层
    :param filter_hs: 卷积窗口的大小
    :param encoder: 编码器的选择
    :return: 创建好的模型
    '''
    print 'Build cnn—lstm model...'
    encode,merge_model = None,[]
    if encoder == 'lstm':
        encode = LSTM(300,dropout_W=0.25, dropout_U=0.25)
    if encoder == 'gru':
        encode = GRU(300, dropout_W=0.25, dropout_U=0.25)

    for filter_h in filter_hs:
        model = Sequential()
        model.add(emb)
        model.add(Convolution1D(nb_filter=300, filter_length=filter_h, border_mode='valid', activation='relu'))
        model.add(MaxPooling1D(pool_length=model.output_shape[1]))
        model.add(encode)
        merge_model.append(model)

    merged = Merge(merge_model, mode='concat')
    model = Sequential()
    model.add(merged)
    model.add(Dropout(0.5))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(loss='binary_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])
    return model

def train_model(datasets,model,model_flag='CNN',batch_size=32):
    '''
    根据datasets和model训练模型
    :param datasets: 数据集
    :param model: 待训练的模型
    :param model_flag: 模型flag
    :param batch_size: mini_batch的尺寸
    :return:保存模型的文件名
    '''
    (X_train, y_train), (X_test, y_test) = datasets
    save_name = None
    if model_flag == 'CNN':
        print 'Train cnn model...'
        save_name = "cnn_model_w.h5"
    if model_flag == 'CNN-LSTM':
        print 'Train cnn-lstm model...'
        save_name = "cnn_lstm_model_w.h5"
    if model_flag == 'CNN-SVM':
        print 'Train cnn-svm model...'
        save_name = "cnn_svm_model_w.h5"

    checkpointer = ModelCheckpoint(filepath=save_name,monitor='val_acc',verbose=1,save_best_only=True,save_weights_only=True)
    history = LossHistory()

    model.fit(  X_train, y_train,
                batch_size=batch_size,
                nb_epoch=30,
                validation_data=(X_test, y_test),
                verbose=2,
                show_accuracy=True,
                callbacks=[checkpointer, history])
    return save_name

def perf_model(datasets,model,save_name,batch_size=32):
    '''
    加载模型，并评测模型结果
    :param datasets: 数据集
    :param model: cnn模型
    :param save_name: 保存的文件名
    :param batch_size: mini_batch的尺寸
    :return: acc,PRF
    '''
    X_test, y_test = datasets[1]
    model.load_weights(save_name)
    score, acc = model.evaluate(X_test, y_test, batch_size=batch_size)
    print 'Test accuracy:', acc

    pred_y = model.predict_classes(X_test, verbose=0)
    PRF = precision_recall_fscore_support(y_test, pred_y, average=None, labels=[0, 1])
    return acc,PRF

def perf_ml_model(datasets,model,save_name,ml='SVM'):
    '''
    加载cnn模型来进行特征提取，用提取的特征评估传统的机器学习模型
    :param datasets:数据集
    :param model:cnn预训练的模型
    :param save_name:模型保存的文件
    :param ml:传统的机器学习模型
    :return:acc, PRF
    '''
    (X_train, y_train), (X_test, y_test) = datasets
    model.load_weights(save_name)
    acc, PRF = None,None
    fea_model = Model(input=model.input, output=model.get_layer('fea_map').output)
    fea_train = fea_model.predict(X_train)
    fed_test = fea_model.predict(X_test)
    if ml == 'SVM':
        acc, PRF = svc(fea_train, y_train, fed_test, y_test)
    if ml == 'RF':
        acc, PRF = rf(fea_train, y_train, fed_test, y_test)
    return acc, PRF

def perf_one_fold(load_data,vocab,pre_w2v,method='CNN',filter_hs=[1,2,3,4],embedding='pre_train',maxlen=600):
    '''
    根据flag抽取pkl的数据，在模型上进行交叉验证，寻找最优模型
    :param load_data: kfold的数据
    :param vocab: 语料词汇词典
    :param pre_w2v: 预先训练的w2v
    :param method: (CNN,CNN-LSTM,CNN-SVM,CNN-RF)
    :param embedding: 词向量的表示方式（rand随机生成、pre_train预训练的词向量）
    :param maxlen: 句子的最大长度
    :return: 模型结果
    '''
    (X_train, y_train), (X_test, y_test) = load_data
    X_train = sequence.pad_sequences(X_train, maxlen=maxlen)
    X_test = sequence.pad_sequences(X_test, maxlen=maxlen)
    datasets = (X_train, y_train), (X_test, y_test)

    encoder, emb ,acc, PRF = None, None, None, None
    vocab_size = len(vocab) + 1

    if embedding == 'rand':
        emb = Embedding(vocab_size,300,dropout=0.25,input_length=maxlen,trainable=True)
    if embedding == 'pre_train':
        emb = Embedding(vocab_size,300,dropout=0.25,weights=[pre_w2v],input_length=maxlen,trainable=True)

    if method == 'CNN-LSTM':
        model = create_cnn_lstm_model(emb,filter_hs = filter_hs,encoder= 'gru')
        save_name = train_model(datasets, model, model_flag=method, batch_size=32)
        acc, PRF = perf_model(datasets, model, save_name,batch_size=32)

    if method in ['CNN','CNN-SVM','CNN-RF']:
        model = create_cnn_model(emb, filter_hs=filter_hs)
        save_name = train_model(datasets, model, model_flag='CNN', batch_size=32)

        if method == 'CNN':
            acc, PRF = perf_model(datasets, model, save_name,batch_size=32)
        if method == 'CNN-SVM':
            acc, PRF = perf_ml_model(datasets, model, save_name)
        if method == 'CNN-RF':
            acc, PRF = perf_ml_model(datasets, model, save_name,ml='RF')

    return acc,PRF

def perf_kfold(flag = 'Pos',kfold = 5):

    accuracy, spam_prf, true_prf = [], [], []
    # 加载数据集
    spam = Spam_process(data_flag=flag)
    revs, pre_w2v, word_idx_map, vocab = spam.get_pkl_data()

    for i in range(kfold):
        print i+1,'of',kfold,'fold data'
        load_data = spam.get_onecv_data(revs, word_idx_map, cv=i)
        acc, PRF = perf_one_fold(load_data,vocab,pre_w2v,method='CNN-LSTM',embedding='pre_train')

        accuracy.append(acc)
        spam_prf.append([PRF[0][0], PRF[1][0], PRF[2][0]])
        true_prf.append([PRF[0][1], PRF[1][1], PRF[2][1]])

    ace_spam_prf, ave_true_prf = np.mean(np.array(spam_prf), axis=0), np.mean(np.array(true_prf), axis=0)
    print 'Average acc:',str(np.mean(accuracy))
    print 'Spam_data P:%.3f R:%.3f F:%.3f' % (ace_spam_prf[0], ace_spam_prf[1], ace_spam_prf[2])
    print 'Truthful_data P:%.3f R:%.3f F:%.3f' % (ave_true_prf[0], ave_true_prf[1], ave_true_prf[2])

    return

if __name__ == '__main__':
    perf_kfold()