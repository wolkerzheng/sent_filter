#coding=utf-8
import numpy as np
np.random.seed(2017)
from keras import backend as K
from keras.models import Model,load_model
from keras.callbacks import Callback,ModelCheckpoint
from keras.layers import Input,Dense, Dropout, Activation, Embedding,RepeatVector,merge
from keras.layers import LSTM, GRU ,Bidirectional,Merge,Flatten,Permute,Lambda,TimeDistributed
from sklearn.metrics import precision_recall_fscore_support
from Attention import Attention
from AttentionWithContext import AttentionWithContext

class LossHistory(Callback):
    def on_train_begin(self, logs={}):
        self.losses = []
    def on_batch_end(self, batch, logs={}):
        self.losses.append(logs.get('loss'))

class lstm_atten():
    '''
    attention lstm(Bi)和lstm、Bi-lism
    '''
    def __init__(self,maxlen,vb_size,pre_w2v):
        self.b_size = 32
        self.nb_epoch = 30
        self.units = 300
        self.drop = 0.35
        self.maxlen = maxlen
        self.vb_size, self.pre_w2v  = vb_size,pre_w2v
        self.encoders ,self.bi, self.att,self.att_con = None,None,None,None

    def get_encoder_param(self,encoder = 'lstm',bi = True,att = False,att_con = False):
        '''
        获得encoder的参数，（lstm,gru,bi,att）,产生文件名
        '''
        B = '_Bi' if bi else ''
        A = '_Att' if att else ''
        AC = '_AttCon' if att_con else ''
        save_to = 'Co_' + encoder + B + A + AC
        self.encoders, self.bi, self.att,self.att_con = encoder,bi,att,att_con
        return save_to

    def get_encoder8flag(self,):
        '''
        获得相应的encoder，以及是否为双向的
        '''
        enco = None
        if self.att or self.att_con:
            if self.encoders == 'lstm':
                enco = LSTM(self.units,return_sequences=True)
            else:
                enco = GRU(self.units,return_sequences=True)
        else:
            if self.encoders == 'lstm':
                enco = LSTM(self.units, )
            else:
                enco = GRU(self.units, )
        if self.bi:
            enco = Bidirectional(enco,merge_mode='ave')

        return enco

    def creat_lstm_model(self,):
        '''
        根据encoders和bi来确定使用lstm、gru和双向
        '''
        encoder = self.get_encoder8flag()
        if not encoder:
            return
        model_input = Input(shape=(self.maxlen,), dtype = 'int32', name = 'model_input')
        x = Embedding(self.vb_size,300,dropout = self.drop,
                      weights=[self.pre_w2v],
                      input_length=self.maxlen,
                      trainable=True)(model_input)
        lstm_out = encoder(x)
        x = Dense(128, activation='relu')(lstm_out)
        x = Dense(128, activation='relu')(x)
        x = Dense(128, activation='relu')(x)
        x = Dropout(0.35)(x)
        model_output = Dense(1, activation='sigmoid', name='model_output')(x)
        model = Model(model_input, model_output)
        model.compile(optimizer='rmsprop', loss='binary_crossentropy',metrics=['accuracy'])

        return model

    def creat_lstm_model_att(self,):
        '''
        根据encoders和bi来确定使用lstm、gru和双向，并使用attention
        '''
        units_num = self.units*2 if self.bi else self.units
        encoder = self.get_encoder8flag()
        if not encoder:
            return
        model_input = Input(shape=(self.maxlen,), dtype='int32', name='model_input')
        embedded = Embedding(self.vb_size, 300,dropout=self.drop,
                      weights=[self.pre_w2v],
                      input_length=self.maxlen,
                      trainable=True)(model_input)
        lstm_out = encoder(embedded)
        #注意力模型
        att = TimeDistributed(Dense(1, activation='tanh'))(lstm_out)
        att = Flatten()(att)
        att = Activation('softmax')(att)
        att = RepeatVector(units_num)(att)
        att = Permute([2, 1])(att)

        sent_c= merge([lstm_out, att], mode='mul')
        sent_c = Lambda(lambda xin: K.sum(xin, axis=1), output_shape=(units_num,))(sent_c)

        x = Dense(128, activation='relu')(sent_c)
        x = Dense(128, activation='relu')(x)
        x = Dense(128, activation='relu')(x)
        x = Dropout(0.35)(x)
        model_output = Dense(1, activation='sigmoid', name='model_output')(x)
        model = Model(model_input, model_output)
        model.compile(optimizer='rmsprop', loss='binary_crossentropy', metrics=['accuracy'])

        return model

    def creat_lstm_model_attvcontext(self):
        '''
        根据encoders和bi来确定使用lstm、gru和双向，并使用上下文指导的attention
        '''
        encoder = self.get_encoder8flag()
        if not encoder:
            return
        model_input = Input(shape=(self.maxlen,), dtype='int32', name='model_input')
        embedded = Embedding(self.vb_size, 300, dropout=self.drop,
                             weights=[self.pre_w2v],
                             input_length=self.maxlen,
                             trainable=True)(model_input)
        lstm_out = encoder(embedded)
        sent_c = AttentionWithContext()(lstm_out)
        x = Dense(128, activation='relu')(sent_c)
        x = Dense(128, activation='relu')(x)
        x = Dense(128, activation='relu')(x)
        x = Dropout(0.35)(x)
        model_output = Dense(1, activation='sigmoid', name='model_output')(x)
        model = Model(model_input, model_output)
        model.compile(optimizer='rmsprop', loss='binary_crossentropy', metrics=['accuracy'])

        return model

    def train_model(self,train_data,test_data,model,file_name):
        '''
        训练相应的模型
        '''
        checkpointer = ModelCheckpoint(filepath=file_name, monitor='val_acc', verbose=1,
                                       save_best_only=True,save_weights_only=False)
        history = LossHistory()
        X_train, y_train = train_data
        X_test, y_test = test_data
        model.fit(X_train, y_train,
                  batch_size=self.b_size,
                  nb_epoch=self.nb_epoch,
                  validation_data=(X_test, y_test),
                  verbose=1,
                  callbacks=[checkpointer, history]
                  )
        return

    def perf_model(self,test_data,file_name,):
        '''
        在测试集上评估模型的表现
        '''
        X_test, y_test = test_data
        if self.att_con:
            model = load_model(file_name,custom_objects={'AttentionWithContext': AttentionWithContext})
        else:
            model = load_model(file_name)
        _, acc = model.evaluate(X_test, y_test, batch_size=self.b_size)
        print 'Test accuracy:', acc

        sig_y = model.predict(X_test,batch_size=self.b_size, verbose=0)
        pred_y =[(i[0] > 0.5).astype('int32') for i in sig_y ]

        PRF = precision_recall_fscore_support(y_test, pred_y, average=None, labels=[0, 1])
        return acc,PRF

if __name__ == '__main__':
    pass