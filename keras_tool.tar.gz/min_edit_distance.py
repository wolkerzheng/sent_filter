#coding=utf-8
import os
import sys
class Med():
    def __init__(self):
        self.word_list = open('words2.txt').read().split('\n')
        self.dist = 2
        return

    def get_minimum_edit_distance(self,word_original, word_input):
        '''
        最小编辑距离矩阵，返回最后一位作为最小编辑距离
        '''
        distance_matrix = [[x for x in range(len(word_original)+1)]]
        for x in range(len(word_input)):
            distance_matrix.append([x+1])

        for x in range(1, len(word_input)+1):
            current_row = distance_matrix[x];
            for y in range(1, len(word_original)+1):
                if(word_input[x-1] == word_original[y-1]):
                    current_row.append(distance_matrix[x-1][y-1])
                else:
                    current_row.append(min([distance_matrix[x-1][y-1], distance_matrix[x-1][y], current_row[y-1]] )+1)

        return distance_matrix[-1][-1]


    def get_ranked_list(self,word_input):
        '''
        获得最小编辑距离列表，排序输出
        '''
        ranked_list = []
        for word in self.word_list:
            distance = self.get_minimum_edit_distance(word, word_input)
            if distance < self.dist:
                ranked_list.append((word, distance))
        def getKey(x):
            return x[1]
        ranked_list.sort(key=getKey)
        return ranked_list

if __name__ == '__main__':
    word_input= 'writong'
    med = Med()
    print med.get_ranked_list(word_input)
