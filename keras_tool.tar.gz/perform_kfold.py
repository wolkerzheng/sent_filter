#coding=utf-8
import numpy as np
np.random.seed(2017)
import os,shutil
from keras import backend as K
from sklearn import metrics
from keras.preprocessing import sequence
from keras.models import Model,load_model
from process_data import Spam_process
from process_data_co import Spam_process_co
from keras_lstm_atten import lstm_atten
from keras_cnn_atten import Cnn_att
from Attention import Attention
from AttentionWithContext import AttentionWithContext
real_path = os.path.dirname(os.path.realpath(__file__))
class Perform_cv():
    '''
    通过交叉验证来评估DL模型的表现
    '''
    def __init__(self,d_flag = 'Pos'):
        self.d_flag = d_flag
        self.maxlen = 300
        self.b_size = 32
        self.kfold = 5
        self.enco_l = ['lstm','gru']
        self.model_flag = None
        self.att, self.att_con,self.bi = None, None,None
        self.lstm_att,self.cnn_att,self.cnn_lstm = None, None,None
        self.vb_size, self.pre_w2v, self.word_idx_map = None, None, None
        self.spam_p = Spam_process(data_flag=self.d_flag)
        self.spam_pco = Spam_process_co(data_flag=self.d_flag)

    def get_init_param(self, glove=True,):
        '''
        初始化lstm或cnn模型的参数
        '''
        ott_revs, co_revs, self.pre_w2v, self.word_idx_map, vocab = self.spam_pco.get_pkl_data(glove=glove)
        self.vb_size = len(vocab) + 1
        assert self.model_flag == 'LSTM' or self.model_flag == 'CNN',"model flag error!"

        if self.model_flag == 'LSTM':
            self.lstm_att = lstm_atten(self.maxlen,self.vb_size,self.pre_w2v)
            self.lstm_att.get_encoder_param(encoder=self.enco_l[0], bi=self.bi, att=self.att, att_con=self.att_con)
        else:
            self.cnn_att = Cnn_att(self.maxlen,self.vb_size,self.pre_w2v)
            self.cnn_att.get_encoder_param(bi=self.bi, att=self.att, att_con=self.att_con, lstm=self.cnn_lstm)

        return ott_revs, co_revs

    def perf_1fold_cnn(self,load_data,file_name):
        '''
        一个交叉验证数据在cnn模型上的效果
        '''
        (X_train, y_train), (X_test, y_test) = load_data
        X_train = sequence.pad_sequences(X_train, maxlen=self.maxlen)
        X_test = sequence.pad_sequences(X_test, maxlen=self.maxlen)
        train_data, test_data = (X_train, y_train), (X_test, y_test)
        if self.cnn_lstm:
            model = self.cnn_att.creat_cnn_lstm_model()
        else:
            model = self.cnn_att.creat_cnn_model()
        self.cnn_att.train_model(train_data, test_data, model, file_name)
        acc, PRF = self.cnn_att.perf_model(test_data, file_name)
        return acc, PRF

    def perf_1fold_lstm(self,load_data,file_name):
        '''
        一个交叉验证数据在lstm模型上效果
        '''
        (X_train, y_train), (X_test, y_test) = load_data
        X_train = sequence.pad_sequences(X_train, maxlen=self.maxlen)
        X_test = sequence.pad_sequences(X_test, maxlen=self.maxlen)
        train_data,test_data = (X_train, y_train), (X_test, y_test)
        assert not self.att or not self.att_con
        if self.att:
            model = self.lstm_att.creat_lstm_model_att()
        elif self.att_con:
            model = self.lstm_att.creat_lstm_model_attvcontext()
        else:
            model = self.lstm_att.creat_lstm_model()
        self.lstm_att.train_model(train_data,test_data,model,file_name)
        acc, PRF = self.lstm_att.perf_model(test_data,file_name)
        return acc, PRF

    def get_model_param(self,method,model_flag = 'lstm',):
        '''
        产生相应的模型参数和保存模型的名称
        '''
        self.bi = True if method['bi'] == 1 else False
        self.att = True if method['att'] == 1 else False
        self.att_con = True if method['att_con'] == 1 else False

        B = '_Bi' if self.bi else ''
        A = '_Att' if self.att else ''
        AC = '_AttCon' if self.att_con else ''

        if model_flag == 'LSTM':
            self.model_flag = 'LSTM'
            save_to = 'Co_' + self.enco_l[0] + B + A + AC

        if model_flag == 'CNN':
            self.model_flag = 'CNN'
            self.cnn_lstm = True if method['cnn_lstm'] == 1 else False
            L = '_lstm' if self.cnn_lstm else ''
            save_to = 'Co_cnn' + L + B + A + AC

        return save_to

    def perf_cv(self,model_flag,method):
        '''
        加载pkl的数据集，5折交叉验证的效果
        '''
        accuracy, spam_prf, true_prf = [], [], []
        save_id = self.get_model_param(method,model_flag = model_flag)
        assert not self.att or not self.att_con
        ott_revs, co_revs = self.get_init_param(glove=True)

        for i in range(self.kfold):
            cv_name = str(i+1) + '_' + save_id
            save_name = real_path + '\\model_params\\' + cv_name
            print save_name
            print i + 1, 'of', self.kfold, 'fold data'
            load_data = self.spam_pco.get_onecv_data(ott_revs, co_revs, self.word_idx_map, cv = i)

            if self.model_flag == 'LSTM':
                acc, PRF = self.perf_1fold_lstm(load_data,save_name)
            else:
                acc, PRF = self.perf_1fold_cnn(load_data,save_name)

            accuracy.append(acc)
            spam_prf.append([PRF[0][0], PRF[1][0], PRF[2][0]])
            true_prf.append([PRF[0][1], PRF[1][1], PRF[2][1]])

        save_to =  'Ott' + save_id
        self.spam_pco.print_save_result(accuracy, spam_prf, true_prf,save_to)
        return

    def perf_one_cv(self,model_flag,method,cv = 0):
        '''
        处理特定的cv，保存模型
        '''
        save_id = self.get_model_param(method, model_flag=model_flag)
        assert not self.att or not self.att_con
        ott_revs, co_revs = self.get_init_param(glove=True)

        cv_name = str(cv + 1) + '_' + save_id
        save_name = real_path + '\\model_params\\' + cv_name
        print save_name
        print cv + 1, 'of', self.kfold, 'fold data'
        load_data = self.spam_pco.get_onecv_data(ott_revs, co_revs, self.word_idx_map, cv=cv)

        if self.model_flag == 'LSTM':
            _, _ = self.perf_1fold_lstm(load_data, save_name)
        else:
            _, _ = self.perf_1fold_cnn(load_data, save_name)

        return

    def get_kfold_testdata(self):
        '''
        产生kfold的测试集数据，用来验证模型效果
        '''
        test_kfold = []
        ott_revs, co_revs, _, self.word_idx_map, _ = self.spam_pco.get_pkl_data(glove=True)
        for i in range(self.kfold):
            _, (X_test, y_test) = self.spam_pco.get_onecv_data(ott_revs, co_revs, self.word_idx_map, cv=i)
            X_test = sequence.pad_sequences(X_test, maxlen=self.maxlen)
            test_kfold.append((X_test, y_test))
        return test_kfold

    def search_best_model(self,model_flag,method):
        '''
        从每个kfold模型，寻找最优模型
        '''
        save_name = self.get_model_param(method, model_flag=model_flag)
        max_acc, max_idx = None, None
        test_kfold = self.get_kfold_testdata()
        for i in range(self.kfold):
            X_test, y_test = test_kfold[i]
            file_name = str(i+1) + '_' + save_name
            model = self.load_1best_model(file_name)
            _, acc = model.evaluate(X_test, y_test, batch_size=self.b_size)
            if acc > max_acc:
                max_acc ,max_idx = acc,i+1

        best_name = str(max_idx)  + '_' + save_name
        self.move2_best_model(best_name,save_name)

        return best_name

    def move2_best_model(self,file_name,save_name):
        '''
        将kfold的最优模型移到model_best路径
        '''
        raw_file = real_path + '\\model_params\\' + file_name
        dst_file = real_path + '\\model_best\\' + save_name
        shutil.copy(raw_file, dst_file)
        return

    def save_1best_model(self,model,file_name):
        '''
        保存one fold中最佳的keras模型
        '''
        model_path = real_path + '\\model_params\\' + file_name
        model.save(model_path)
        del model

    def load_1best_model(self,file_name):
        '''
        加载one fold中最佳的keras模型
        '''
        model_path = real_path + '\\model_params\\' + file_name
        assert os.path.exists(model_path)
        if self.att_con:
            model = load_model(model_path,custom_objects={'AttentionWithContext': AttentionWithContext})
        elif self.att:
            if self.model_flag == 'CNN':
                model = load_model(model_path, custom_objects={'Attention': Attention})
            else:
                model = load_model(model_path)
        else:
            model = load_model(model_path)
        return model

if __name__ == '__main__':
    per_cv = Perform_cv(d_flag='Pos')

    '''model_flag = 'CNN'
    method = {'bi': 1, 'att': 0, 'att_con': 0, 'cnn_lstm': 1}
    per_cv.perf_cv(model_flag, method,)

    method = {'bi': 1, 'att': 1, 'att_con': 0, 'cnn_lstm': 1}
    per_cv.perf_cv(model_flag, method,)

    method = {'bi': 1, 'att': 0, 'att_con': 1, 'cnn_lstm': 1}
    per_cv.perf_cv(model_flag, method,)'''

    model_flag = 'LSTM'
    method = {'bi': 1, 'att': 0, 'att_con': 1, 'cnn_lstm': 0 }
    per_cv.perf_cv(model_flag, method)

    '''model_flag = 'LSTM'
    method = {'bi': 0, 'att': 0, 'att_con': 1, 'cnn_lstm': 0}
    per_cv.search_best_model(model_flag, method)'''

