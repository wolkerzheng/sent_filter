'''Trains a LSTM on the IMDB sentiment classification task.
The dataset is actually too small for LSTM to be of any advantage
compared to simpler, much faster methods such as TF-IDF + LogReg.
Notes:

- RNNs are tricky. Choice of batch size is important,
choice of loss and optimizer is critical, etc.
Some configurations won't converge.

- LSTM loss decrease patterns during training can be quite different
from what you see with CNNs/MLPs/etc.
'''
import os,time
import pre_srt_conv as srt
import numpy as np
np.random.seed(94) 
import cPickle as pickle
from pre_build_dictionary import word_dictionary
from keras.preprocessing import sequence
from keras.models import Model
from keras.layers import Dense, Embedding, Dropout, Input, merge
from keras.layers import LSTM
from keras.callbacks import EarlyStopping
from sklearn.cross_validation import train_test_split

max_features = 30000
batch_size = 128
SEED = 94
max_features = 30000
word_vec_dim = 200
embbeding_dim = word_vec_dim*4
conv_max_len = 15
sent_max_len = 30
steps_per_epoch = int(190000/batch_size)

pkl_file = open('word2vecljw2v.pkl', 'rb')
embedding_weights = pickle.load(pkl_file)

def process_line(line):
	arr = list(map(int, line.strip().split()))
	x, y = arr[:-1], arr[-1]
	x = np.array(x).reshape((conv_max_len, sent_max_len))
	temp_x = np.zeros((sent_max_len, word_vec_dim))
	temp_xx = np.zeros((conv_max_len, embbeding_dim))
	for i in range(x.shape[0]):
		for j in range(x.shape[1]):
			temp_x[j,:] = embedding_weights[x[i,j],:]
		temp_xx[i, :word_vec_dim] = np.sum(temp_x)
		temp_xx[i, word_vec_dim:word_vec_dim*2] = np.mean(temp_x)
		temp_xx[i, word_vec_dim*2:word_vec_dim*3] = np.min(temp_x)
		temp_xx[i, word_vec_dim*3:word_vec_dim*4] = np.max(temp_x)
	return temp_xx, y

def generate_arrays_from_file(path):
	f = open(path, 'rb')
	res_x, res_y = np.zeros((batch_size,conv_max_len, embbeding_dim)), np.zeros(batch_size).astype(int)
	line_count = 0
	for line in f:
		if line_count<batch_size:
			# create numpy arrays of input data
			# and labels, from each line in the file
			x1, y = process_line(line)
			res_x[line_count,:,:] = x1[:,:]
			res_y[line_count] = y
			line_count += 1
			continue
		yield ({'input': res_x}, {'output': res_y})
		line_count = 0
	f.close()

def run():
	print('Loading data...')
	positive_data, negtive_data = srt.load_data()

	input_conv = Input(name='input', shape=(conv_max_len,embbeding_dim,))
	lstm_out_forward = LSTM(embbeding_dim)(input_conv)
	lstm_out_forward_dropout = Dropout(0.5)(lstm_out_forward)
	lstm_out_backward = LSTM(embbeding_dim)(input_conv)
	lstm_out_backward_dropout = Dropout(0.5)(lstm_out_backward)
	x = merge([lstm_out_forward_dropout, lstm_out_backward_dropout], mode='concat')
	x = Dense(300)(x)
	x = Dense(300)(x)
	x = Dense(300)(x)
	x = Dense(1, activation='sigmoid', name='output')(x)

	# try using different optimizers and different optimizer configs
	model = Model(inputs=input_conv, outputs=x)
	model.compile(loss='binary_crossentropy',
	              optimizer='adam',
	              metrics=['accuracy'])
	early_stopping =EarlyStopping(monitor='val_loss', patience=4)  
	t1 = time.time()
	print('Train...')
	hist = model.fit_generator(generate_arrays_from_file('train0.txt'),
	          # batch_size=batch_size,
	          steps_per_epoch=steps_per_epoch,
	          epochs=50,
	          verbose=1,
	          callbacks=[early_stopping],
	          validation_data=generate_arrays_from_file('output_train1.txt'),
	          validation_steps=800,
	          )
	print hist.history

	score, acc = model.evaluate_generator(generate_arrays_from_file('output_train1.txt'),
	                            # batch_size=batch_size
	                            )
	print('Test score:', score)
	print('Test accuracy:', acc)

	t2 = time.time()
	print (t2-t1)

if __name__ == '__main__':
	run()
	# f = open('train1.txt', 'rb')
	# i = 0
	# for line in f:
	# 	i += 1
	# 	if i > 10:
	# 		break
	# 	line_count = 0
	# 	res_x, res_y = np.zeros((batch_size,conv_max_len, embbeding_dim)), np.zeros((batch_size, 1))
	# 	while line_count<batch_size:
	# 		# create numpy arrays of input data
	# 		# and labels, from each line in the file
	# 		x1, y = process_line(line)
	# 		res_x[line_count,:,:] = x1[:,:]
	# 		res_y[line_count] = y
	# 		line_count += 1

	# 	print res_x.shape
	# 	print res_y.shape
