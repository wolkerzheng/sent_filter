# -*- coding:utf-8 -*-
"""
 date: 2017-08-31 14:57:09
 author: Chengze Wu
 describe: 使用预训练好的层次lstm模型判别每个多轮对话质量是否合格
"""
from keras.models import load_model
from keras.models import Model
import jieba
import json
import re
import numpy as np
from pre_build_dictionary import word_dictionary
import cPickle as pickle
import codecs
maxlen = 250
batch_size = 128

def json_generator(in_filename=None):
	input_file = codecs.open(in_filename, 'r', 'utf-8')
	print input_file
	LAST_TITLE = ''
	line = input_file.readline()
	thread = json.loads(line)
	temp = extrac(thread)
	while not (not isinstance(temp['title'], type(None))) and not len(temp['html']) == 0:
		line = input_file.readline()
		thread = json.loads(line)
		temp = extrac(thread)
		print 'error'
		continue
	print '1'
	data = temp
	continue_flag = False
	for line in input_file:
		print '2'
		thread = json.loads(line)
		temp = extrac(thread)
		if (not isinstance(temp['title'], type(None))) and not len(temp['html']) == 0:
			if not temp['title'] == LAST_TITLE:
				LAST_TITLE = temp['title']
				yield data
				# return data
				data = temp
				continue_flag = False
			else:
				data['html'].extend(temp['html'])
				continue_flag = True
	if continue_flag:
		yield data
		# return data

	input_file.close()

def pair_sort(pair_list):
    temp = pair_list
    pair_list = []
    for i in range(len(temp)):
        pair_list.append(temp[i])
        latter = temp[i][1]
        for j in range(i,len(temp)):
            if temp[j][0] == latter:
                pair_list.append(temp[j])
                latter = temp[j][1]
    return pair_list

def has_lzl(tiezi):
    tag = False
    for com in tiezi['html']:
        if 'lzl' in com.keys():
            tag = True
    return tag

def title_proc(title, title_descrip): 
    title_descrip = re.sub(ur'<.*>', '', title_descrip)
    title_descrip = re.sub(ur'\n+|\t+|[^\u4e00-\u9fa5a-z0-9,.!?，．！～？:：\s~@]+', '', title_descrip)
    title_descrip = re.sub(ur'\s+', ur' ', title_descrip)
    title = re.sub(ur'<.*>|\n+|\t+', '', title)
    title = re.sub(ur'\s+', ur' ', title)
    if len(title_descrip) >= 300:
        # print(title_descrip)
        title_descrip = ''

    title = re.sub(ur'^[\u4e00-\u9fa5]{2}:|(转帖)|【.*?】|(.*?)|\[.*?\]|『.*?』|〖.*?〗]|【.*?〗|\|.*?\|『.*?』|','', title)
    title = re.sub(ur'^【.*?〗|〔.*?〕', '', title)
    title = re.sub(ur'_.*?_百度贴吧$', '', title)
    title = re.sub(ur'[^\u4e00-\u9fa5a-z0-9,.!?，．！～？:：\s~@]+', '', title)
    # title = re.sub(invalid_word, '', title)
    title = ''.join([i for i in jieba.cut(title, cut_all=False) if not i == ' '])

    # 词数量
    # title = ' '.join(jieba.cut(title,))
    # if title_descrip != '':
    #     title_descrip = re.sub(ur'[^\u4e00-\u9fa5|^a-z|^0-9]+', '', title_descrip)
    #     title_descrip = ' '.join([i for i in jieba.cut(title_descrip, cut_all=False) if not i == ' '])
    #     if len(set(title.split()).union(set(title_descrip.split()))) <= 4:
    #         return None, None
    # elif len(set(title.split())) <= 4:
    #     return None, None
    print title, title_descrip
    return title, title_descrip

def comment_proc(comment):
    content = comment['content']

    if len(content) >=100 or comment == '':
        return None
    content = re.sub(ur'--|', '', content)
    content = re.sub(ur'<.*>|\n+|\t+|[^\u4e00-\u9fa5a-z0-9,.!?，．！～？:：\s~@]+', '', content)
    content = re.sub(ur'\s+', ur' ', content)
    # content = re.sub(invalid_word, '', content)
    if len(set([i for i in jieba.cut(content, cut_all=False)]) )<= 3:
        return False
    else:
        comment['content'] = ''.join(content.split())
        # comment['content'] = content
        return True

def lzl_extrac(comment):
    # pre_name = [comment['name']]
    comment['qa_pair'] = []

    i = 0
    while i < len(comment['lzl']) :
        content = comment['lzl'][i]['content']
        name = re.findall(ur'(?<=回复\s).*?(?=\s:)|(?<=回复\s).*?(?=\s：)', comment['lzl'][i]['content'])
        content = re.sub(ur'--|', '', content)
        content = re.sub(ur'<.*>|\n+|\t+|[^\u4e00-\u9fa5a-z0-9,.!?，．！～？:：\s~@]+', '', content)
        content = re.sub(ur'\s+', ur' ', content)
        if len(content) >100:
            comment['lzl'][i]['content'] = ''
        else:
            comment['lzl'][i]['content'] = content
        if len(name) >0:
            comment['lzl'][i]['reply_name'] = name[0]
        else:
            comment['lzl'][i]['reply_name'] = ''        
        #     comment['lzl'][i]['reply_name'] = comment['name']
        
        comment['lzl'][i]['content'] = re.sub(ur'回复.*?(:|：)','', comment['lzl'][i]['content'])
        #guo lv feifa zifu 
        comment['lzl'][i]['content'] = re.sub(ur'<.*>', '', comment['lzl'][i]['content'])
        comment['lzl'][i]['content'] = re.sub(ur'<.*>|[^\u4e00-\u9fa5a-z0-9,.!?，．！～？:：\s~@]]+', '', comment['lzl'][i]['content'])
        i += 1

def cut_same(html):
    count = {}
    comment_list = [html[i]['content'] for i in range(len(html))]

    for i in html:
        if comment_list.count(i['content']) >= 2:
            html.remove(i)
    # for i in html:
    #     print i['content']
    return html

def extrac(thread):#chuli title,title_descrip ; 
    re_thread = []
    pronedata = []
    url = thread['url']
    html = thread['html']
    author = html[0]['name']
    author_level = html[0]['grade_level']

    # 处理title并以一楼回复作为问题描述
    title, title_descrip = title_proc(thread['title'], html[0]['content'])

    re_html = []
    for com in html:
        if comment_proc(com):
            re_html.append(com)
    re_html = cut_same(re_html)

    for com in re_html:
        if 'lzl' in com.keys():
            lzl_extrac(com)

    re_thread={'title': title, 'title_descrip': title_descrip, 'html': re_html, 'url': url, 'author': author,
               'author_level': author_level}

    return re_thread

def sen_pro(sent):
    # sent = re.sub(ur'[^\u4e00-\u9fa5a-z0-9]+', '', sent)
    # stopword = [line for line in f.readlines()]
    ll = ' '.join([i for i in jieba.cut(sent, cut_all=False) if not i == ' '])
    return ll

def lzljs2list(lzl, floor_name, floor_content):#lzl: comm['lzl'] e.g. [lzl1,lzl2,lzl3] , lzl1:{content,user_id,name,time,reply_name(can be '')}
	res = []
	reply_name_dict ={}
	replyto_name_dict= {}
	edge = []
	reply_name_dict[floor_name] = 0
	for i, i_floor in enumerate(lzl):
		#1L
		print i_floor['name'],'#', i_floor['reply_name'], '#',i_floor['content'],i
		if i_floor['reply_name'] == '':
			# print i,'replyname is null'
			if i_floor['name'] not in replyto_name_dict.keys():
				edge.append((0, i+1))
			else:
				edge.append((replyto_name_dict[i_floor['name']], i+1))
		elif i_floor['name'] in reply_name_dict.keys() and i_floor['reply_name'] in replyto_name_dict.keys() and reply_name_dict[i_floor['name']] == replyto_name_dict[i_floor['reply_name'
		]] and i_floor['reply_name'] in reply_name_dict.keys() and  reply_name_dict[i_floor['reply_name']]<reply_name_dict[i_floor['name']]:
			# print i,'this floor is same as ' , reply_name_dict[i_floor['name']]
			lzl[reply_name_dict[i_floor['name']]-1]['content'] = lzl[reply_name_dict[i_floor['name']]-1]['content']+i_floor['content']
			continue
		elif not i_floor['reply_name'] in reply_name_dict:
			print i,'replyname dont exist'
		
		else :
			# print 'A:B,add edge'
			edge.append(( reply_name_dict[i_floor['reply_name']],i+1))
		reply_name_dict[i_floor['name']] = i+1
		replyto_name_dict[i_floor['reply_name']] = i+1


	comment_thread = []
	thread_list = []
	dfstravrse(len(lzl)+1, edge, thread_list) #dfs
	print thread_list
	for thread in thread_list:
		thread_temp = []
		if len(thread)>1:
			for i in thread:
				if i ==0 :
					thread_temp.append(floor_content)
				else:
					thread_temp.append(lzl[i-1]['content'])
			# comment_thread.append(';'.join([floor['content'] for i,floor in enumerate(lzl) if i in thread]))
			comment_thread.append(thread_temp)
	# print comment_thread
	return comment_thread #[[com1,com2,com3],[],[],...]
def dfs(edge, v, visited, stack, res):
	visited[v]=1
	stack.append(v)
	adjvex = [temp[1] for temp in edge if temp[0] == v]
	if len(adjvex) == 0 :
		res.append(stack[:]) #qian fu zhi
	for i in adjvex:
		if visited[i] ==0:
			dfs(edge, i, visited, stack, res)
	stack.pop()

def dfstravrse(node, edge, res):
	visited = [0]*node
	stack = []
	for i in range(node):
		if visited[i] == 0:
			dfs(edge, i, visited, stack, res)
	for thread in res:
		if len(thread) == 1:
			res.remove(thread)

#input : json, {url, html, fans_num, title, title_descrip, author, author_level}, 
#html: [comment1,comment2...], comment1:[floor,content,name,grade_level]
def js2list(input_json):
	#texts to cut
	texts_raw = []
	total_text_nums = 1
	comment_id = 1
	print input_json['url']
	#text , name , id_level , id_fans. reply_to_name
	# texts_raw.append([comment_id , input_json['title'] + input_json['title_descrip'] , input_json['author'], 
	# # 	input_json['author_level'], -1 ,'']) #fans_num is null
	# print input_json['title'], input_json['title_descrip'], input_json['author']
	# print input_json['url']
	for comm in input_json['html']:
		#add comment
		if 'lzl' in comm.keys():
			comment_thread =lzljs2list(comm['lzl'], comm['name'], comm['content'])
			if comm['name'] == input_json['author']:
				continue
			for thread in comment_thread:
				thread.insert(0, input_json['title'] + input_json['title_descrip'])
				if '' not in thread:
					thread_text = ';'.join(thread)	
					texts_raw.append(thread_text)
	return texts_raw

def transform(input_generator):
	i = 0
	for temp in data:
		tiezi = js2list(input_json=temp)
		for thread in tiezi :
			if len(thread.split(';')) >= 4: # dui hua chang du 
				yield thread

import traceback

"""
 function: predict conversaiton is valid or not.
 parameter:
 model: model used to predict.
 conv_generator:
 output_path: path to save the postive conversation.
 output_path2: path to save the negtive conversation.
 positive_eva: 
"""
def predict(model, 	conv_generator, output_path, output_path2, positive_eva=0.53):
	output_file = codecs.open(output_path+'.txt', 'wb', 'utf-8')
	if output_path2 :
		output_file2 = codecs.open(output_path2+'.txt', 'wb', 'utf-8')
	try:
		batch_data = []
		line_count = 0
		for line in conv_generator:
			# get batch size conversation
			if line_count<batch_size:	
				# if np.random.binomial(1,0.1):
					# continue
				conv = line.split()
				for sentid, sent in enumerate(conv):
					conv[sentid] = '/'.join([i for i in jieba.cut(sent, cut_all=False) if not i == ' '])
				batch_data.append(conv)
				line_count += 1
				continue
			intdata = word_dict.pad_transform(batch_data,maxlen)
			y = model.predict_on_batch(intdata)
			for i in range(len(batch_data)):
				line = ';'.join(batch_data[i])
				# print type(line)
				line = line + '\n'
				if y[i] > positive_eva:
					output_file.write(line)
				# elif y[i] < 0.3 :
					# output_file2.write(line)
			line_count = 0
			batch_data = []
	except:
		traceback.print_exc()
		output_file.close()

def predict2(conv_generator, output_path, output_path2, positive_eva=0.53):
	word_dict = word_dictionary()
	word_dict.load_dictionary('word2vec_dict.txt')
	pkl_file = open('word2vecljw2v.pkl', 'rb')
	embedding_weights = pickle.load(pkl_file)
	model = load_model('../model/model_negtive1_hierarchical_lstm.h5')
	output_file = codecs.open(output_path+'.txt', 'wb', 'utf-8')
	if output_path2:
		output_file2 = codecs.open(output_path2+'.txt', 'wb', 'utf-8')
	try:
		batch_data = []
		line_count = 0
		for line in conv_generator:
			if line_count<batch_size:
				#random	
				if np.random.binomial(1,0.1): 
					continue
				conv = line.split()
				for sentid, sent in enumerate(conv):
					conv[sentid] = '/'.join([i for i in jieba.cut(sent, cut_all=False) if not i==' '])
				batch_data.append(conv)
				line_count += 1
				continue
			intdata = word_dict.pad_transform(batch_data,maxlen)
			y = model.predict_on_batch(intdata)
			print y
			for i in range(len(batch_data)):
				line = ';'.join(batch_data[i])
				print type(line)
				line = line + ' ' + str(y[i]) + '\n'
				if y[i] > positive_eva:
					output_file.write(line)
				# elif y[i] < 0.3 :
					# output_file2.write(line)
			line_count = 0
			batch_data = []
	except:
		traceback.print_exc()
		output_file.close()


	output_file.close()

#use labeled data evaluate model
import matplotlib.pyplot as plt
def evaluate():
	f = open('../output/tieba_73082_161205_threadcut_1_labeled', 'r')

	x_test = []
	y_test = []
	for line in f:
		conv = line.split('#')
		conv_id = conv[0]
		conv_text = conv[1]
		conv_score = conv[2]
		score_len = len(conv_score.split(';'))
		if score_len != 5: #filter valid score
			continue
		conv_text = conv_text.split(';')
		for sentid, sent in enumerate(conv_text):
			conv_text[sentid] = '/'.join([i for i in jieba.cut(sent, cut_all=False) if not i == ' '])
		x_test.append(conv_text)
		seq_score = np.array(range(20,0,-1))
		seq_sum_score = np.sum(seq_score) * 3
		conv_score = conv_score.split(';')
		question_score = float(conv_score[0])/5
		pair_score_list = np.zeros(20)
		temp = conv_score[1]
		temp = np.array(list(map(float, temp)))
		pair_score_list[:temp.shape[0]] = temp
		pair_score = np.dot(seq_score, pair_score_list)/seq_sum_score
		
		connective_score_list = np.zeros(20)
		temp = conv_score[2]
		temp = np.array(list(map(float, temp)))
		connective_score_list[:temp.shape[0]] = temp
		connective_score = np.dot(seq_score, connective_score_list)/seq_sum_score
		
		topic_score = float(conv_score[3])/5
		end_score = float(conv_score[4])/5

		score = np.mean([connective_score, topic_score, topic_score])
		y_test.append(score)

	y_test = sorted(y_test)
	mid = y_test[len(y_test)/2]
	f.close()
	word_dict = word_dictionary()
	word_dict.load_dictionary('word2vec_dict.txt')
	pkl_file = open('word2vecljw2v.pkl', 'rb')
	embedding_weights = pickle.load(pkl_file)
	model = load_model('../model/my_model.h5')
	intdata = word_dict.pad_transform(x_test,maxlen)
	predict = model.predict(intdata)

	print predict
	print y_test
	y_bi = list(map(lambda x:1 if x>=mid else 0, y_test))
	y_sum = sum(y_bi) + 1e-7
	print y_sum/len(y_bi), mid
	acc_list = []
	recall_list = []

	for i in range(len(x_test)):
		if predict[i]>0.47:
			for sent in x_test[i]:
				print sent
			print y_test[i], predict[i]
			print '----------------------'
	for eva in map(lambda x:float(x)/100, range(0, 80, 1)):
		predict_bi = list(map(lambda x:1 if x>=eva else 0, predict))
		predict_sum = sum(predict_bi) + 1e-7
		acc_count= 0
		for i, label in enumerate(predict_bi):
			if y_bi[i] == predict_bi[i] and y_bi[i] == 1:
				acc_count += 1
		if acc_count == 0:
			break
		acc = acc_count/predict_sum
		recall = acc_count/y_sum
		print eva, acc_count, predict_sum, acc, recall
		acc_list.append(acc)
		recall_list.append(recall)
	
	fig = plt.figure()
	ax = fig.add_subplot(1, 1, 1)
	ax.plot(recall_list, acc_list, 'ko--')
	ax.set_xlabel('recall')
	ax.set_ylabel('precision')
	plt.show()

# evaluate()


import os
import gzip
def gzip_json_generator(in_filename=None):
	input_file = gzip.GzipFile(in_filename, 'r', 'utf-8')
	print input_file
	LAST_TITLE = ''
	line = input_file.readline()
	print line
	thread = json.loads(line)
	print thread
	temp = extrac(thread)
	while not (not isinstance(temp['title'], type(None))) and not len(temp['html']) == 0:
		line = input_file.readline()
		thread = json.loads(line)
		temp = extrac(thread)
		print 'error'
		continue
	print '1'
	data = temp
	continue_flag = False
	for line in input_file:
		print '2'
		thread = json.loads(line)
		temp = extrac(thread)
		if (not isinstance(temp['title'], type(None))) and not len(temp['html']) == 0:
			if not temp['title'] == LAST_TITLE:
				LAST_TITLE = temp['title']
				yield data
				# return data
				data = temp
				continue_flag = False
			else:
				data['html'].extend(temp['html'])
				continue_flag = True
	if continue_flag:
		yield data
		# return data
	input_file.close()

import re
path = '/media/wu/disk3/corpus_tieba/'
outputfile_root = '/media/wu/disk1/corpus_data_result/'
word_dict = word_dictionary()
word_dict.load_dictionary('word2vec_dict.txt')
pkl_file = open('word2vecljw2v.pkl', 'rb')
embedding_weights = pickle.load(pkl_file)
model = load_model('../model/my_model.h5')
for filename in os.listdir(path):
	if re.match(ur'.*\.gz', filename):
		file = os.path.join(path, filename)
		input_file = file
		output_file = os.path.join(outputfile_root, filename)
		data = gzip_json_generator(input_file)
		conv_list = transform(data)
		predict(model, conv_list, output_file, None, 0.48)

# file = '/media/wu/disk2/corpus_data/part-00001'
# outputfile_root = '/media/wu/disk1/corpus_data_result/'
# input_file = file
# output_file = outputfile_root + '-out-positive-0.48'
# output_file2 = file + '-out-negtive'
# data = json_generator(input_file)
# conv_list = transform(data)
# predict(conv_list, output_file, None, 0.48)


'''
f = open('../output/tieba_73082_161205_threadcut_1')
data = []
for line in f.readlines():
	conv = line.split()
	for sentid, sent in enumerate(conv):
		conv[sentid] = '/'.join([i for i in jieba.cut(sent, cut_all=False) if not i == ' '])
	data.append(conv)

word_dict = word_dictionary()
word_dict.load_dictionary('word2vec_dict.txt')
pkl_file = open('word2vecljw2v.pkl', 'rb')
embedding_weights = pickle.load(pkl_file)

intdata = word_dict.pad_transform(data,maxlen)
model = load_model('../model/my_model.h5')

y = model.predict(intdata, batch_size=128, verbose=0)
f.close()
f = codecs.open('output1.txt', 'wb')
for i in range(len(data)):
	line = ';'.join(data[i])
	if y[i] > 0.5:
		line = line + ' ' + str(y[i]) + '\n'
		print line

f.close()
'''
