'''Trains a LSTM on the IMDB sentiment classification task.
The dataset is actually too small for LSTM to be of any advantage
compared to simpler, much faster methods such as TF-IDF + LogReg.
Notes:

- RNNs are tricky. Choice of batch size is important,
choice of loss and optimizer is critical, etc.
Some configurations won't converge.

- LSTM loss decrease patterns during training can be quite different
from what you see with CNNs/MLPs/etc.
'''
import os,time
import pre_srt_conv as srt
import numpy as np
import sys
np.random.seed(94) 
import cPickle as pickle
from pre_build_dictionary import word_dictionary
from sklearn.cross_validation import train_test_split
from keras.preprocessing import sequence
from keras.models import Model
from keras.layers import Dense, Embedding, Dropout, Input, merge
from keras.layers import LSTM, Flatten, Activation, RepeatVector, Permute, Lambda
from keras.callbacks import EarlyStopping
from keras.layers.wrappers import Bidirectional, TimeDistributed
from keras import backend as K

max_features = 30000
batch_size = 64
SEED = 94
max_features = 30000
embedding_len = 200
conv_max_len = 15
sent_max_len = 30
train_nums = 197481
valid_nums = 97267

pkl_file = open('word2vecljw2v.pkl', 'rb')
embedding_weights = pickle.load(pkl_file)
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 0) 
# input: a\b\c\d;a\b\c\d
# output: shape = (conv_max_len, sent_max_len, embedding_len)
def process_line(line):
	arr = list(map(int, line.strip().split()))
	x_input, y = arr[:-1], arr[-1]
	x_input = np.array(x_input).reshape((conv_max_len, sent_max_len))
	x_output = np.zeros((conv_max_len, sent_max_len, embedding_len))
	for i in range(x_input.shape[0]):
		for j in range(x_input.shape[1]):
			x_output[i,j,:] = embedding_weights[x_input[i,j],:]
	return x_output, y

def generate_arrays_from_file(path):
	while 1:
		f = open(path, 'rb')
		res_x = np.zeros((batch_size,conv_max_len, sent_max_len, embedding_len))
		res_y = np.zeros(batch_size).astype(int)
		line_count = 0
		for line in f.readlines():
			if line_count<batch_size:
				# create numpy arrays of input data
				# and labels, from each line in the file
				X, y = process_line(line)
				assert len(X.shape) == 3
				res_x[line_count,:,:,:] = X[:,:,:]
				res_y[line_count] = y
				line_count += 1
				continue
			line_count = 0
			yield ({'input': res_x}, {'output': res_y})
			f.close()
	return 

def run():
	t1 = time.time()
	sentence_input = Input(shape=(sent_max_len,embedding_len ))
	l_lstm = Bidirectional(LSTM(200, input_dim=200, input_length=sent_max_len, return_sequences=True))(sentence_input)
	attention = Dense(1, activation='tanh')(l_lstm)
	attention = Flatten()(attention)
	attention = Activation('softmax')(attention)
	attention = RepeatVector(400)(attention)
	attention = Permute([2,1])(attention)
	sent_representation = merge([l_lstm, attention], mode='mul')
	sent_representation = Lambda(lambda xin: K.sum(xin, axis=-2), output_shape=(400,))(sent_representation)
	sentEncoder = Model(inputs=sentence_input, outputs=sent_representation)

	# conv_input = Input(name='input', shape=(conv_max_len, sent_max_len, embedding_len))
	# conv_encoder = TimeDistributed(sentEncoder)(conv_input)
	# l_lstm_sent = Bidirectional(LSTM(200, return_sequences=True))(conv_encoder)
	# att_sent = Dense(1, activation='tanh')(l_lstm_sent)
	# att_sent = Flatten()(att_sent)
	# att_sent = Activation('softmax')(att_sent)
	# att_sent = RepeatVector(400)(att_sent)
	# att_sent = Permute([2,1])(att_sent)
	# conv_representation = merge([l_lstm_sent, att_sent], mode='mul')
	# conv_representation = Lambda(lambda xin: K.sum(xin, axis=-2), output_shape=(400,))(conv_representation)

	conv_input = Input(name='input', shape=(conv_max_len, sent_max_len, embedding_len))
	conv_encoder = TimeDistributed(sentEncoder)(conv_input)
	l_lstm_sent = Bidirectional(LSTM(200))(conv_encoder)
	l_lstm_sent = Dropout(0.5)(l_lstm_sent)
	l_lstm_sent = Dropout(0.5)(l_lstm_sent)
	preds = Dense(1, activation='sigmoid', name='output')(l_lstm_sent)
	model = Model(inputs=conv_input, output=preds)
	model.summary()
	model.compile(loss='binary_crossentropy',
	              optimizer='adam',
	              metrics=['accuracy'])
	early_stopping =EarlyStopping(monitor='val_loss', patience=4)
	hist = model.fit_generator(generate_arrays_from_file('output_train0.txt'),
          # batch_size=batch_size,
          steps_per_epoch=int(train_nums/batch_size),
          epochs=3,
          verbose=2,
          callbacks=[early_stopping],
          validation_data=generate_arrays_from_file('output_train1.txt'),
          validation_steps=int(valid_nums/batch_size),
          )
	print hist.history
	model.save('../model/model_negtive1_hierarchical_lstm.h5')
	score, acc = model.evaluate_generator(generate_arrays_from_file('output_train1.txt'),
                            steps=int(valid_nums/batch_size)
                            )
	print('Test score:', score)
	print('Test accuracy:', acc)
	t2 = time.time()
	print 'trainning cost time: ', (t2-t1), 's'

if __name__ == '__main__':
	run()