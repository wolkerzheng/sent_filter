
import pre_srt_conv as srt_conv
import numpy as np
from collections import Counter
import numpy as np
import cPickle as pickle
from nltk.corpus import stopwords


class word_dictionary():
	def __init__(self, stopwords_path='../input/stopwords.txt'):
		self.word_dict = dict() #dict word 2 int
		self.val_dist = dict() #dict int 2 word
		self.word_counter = Counter() #word count
		self.sentence_maxlen = 0 #max sentence length
		self.max_features = 0 
		self.para_maxlen = 0 #paragraph max length
		self.stop_words={}
		f = open(stopwords_path, 'r')
		for line in f.readlines():
			word = line.strip()
			self.stop_words[word] = 1
		return 

	def fit(self, data, filter_stopwords=False): #input like [[[word1/word2/word3],[],...[]], [[],[]...], ... ,]
		if not data:
			print 'data is null'
			return None
		else:
			for conversation in data:
				for sentence in conversation:
					for word in sentence.split('/'):
						if word != '' and not self.stop_words.get(word, 0):
							self.word_counter.update(([word]))
		item_list = sorted(self.word_counter.most_common(), key = lambda x : x[1], reverse = True) #order word dict from 1 to n with frequences
		self.word_dict = dict(zip([item_list[i][0] for i in range(len(item_list))], range(1,1+len(item_list))))
		self.val_dict = dict(zip(range(1,1+len(item_list)), [item_list[i][0] for i in range(len(item_list))]))
		self.max_features = len(item_list)
		return 

	def save_dictionary(self,path='dictionary.txt'): #save dict 
		if self.word_counter:
			with open(path, 'w') as f : 
				item_list = sorted(self.word_counter.most_common(), key = lambda x : x[1], reverse = True)
				for key, value in item_list:
					f.write(key+' '+str(value)+'\n')
		elif self.word_dict:
			with open(path, 'w') as f : 
				item_list = sorted(self.word_dict.items(), key = lambda x : x[1])
				for key, value in item_list:
					f.write(key+' '+str(value)+'\n')
		else:
			print 'dictionary is null'
			return
		print 'finish saving dict'
		return

	def get_topk_words(self,k): #get top k words
		return self.word_counter.most_common(k)

	def load_dictionary(self,path= 'dictionary.txt'): #load dict
		key_list = []
		val_list = []
		item_list = sorted(self.word_counter.most_common(), key = lambda x : x[1], reverse = True)
		with open(path, 'r') as f : 
			for line in f.readlines():
				key, val = line.strip().split()
				item_list.append((key,int(val)))
		self.word_dict = dict(zip([item_list[i][0] for i in range(len(item_list))], range(1,1+len(item_list))))
		self.val_dict = dict(zip(range(1,1+len(item_list)), [item_list[i][0] for i in range(len(item_list))]))
		self.max_features = len(item_list)
		print 'finish loading'
		return

	def update_dictionary(self,data = None,path=None): #updata dict with data
		if not data:
			print 'data is null'
			return None
		else:
			for conversation in data:
				for sentence in conversation:
					for word in sentence.split('/'):
						if word != '':
							self.word_counter.update(([word]))
		item_list = sorted(self.word_counter.most_common(), key = lambda x : x[1], reverse = True)
		self.word_dict = dict(zip([item_list[i][0] for i in range(len(item_list))], range(1,1+len(item_list))))
		self.val_dict = dict(zip(range(1,1+len(item_list)), [item_list[i][0] for i in range(len(item_list))]))
		self.max_features = len(item_list)
		return

	def transform(self,data): #return conversation * sentences * words
		new_data = [[] for _ in range(len(data))]
		for i, conversation in enumerate(data):
			for j, sentence in enumerate(conversation):
				sentence_list = [word for word in sentence.strip().split('/') if word != '']
				self.sentence_maxlen = max(self.sentence_maxlen, len(sentence_list))
				temp = list(map(lambda x:0 if self.word_dict.get(x)== None else self.word_dict.get(x), sentence_list)) #wei deng lu ci id wei 0
				new_data[i].append(temp)
		return new_data

	def pad_transform(self, data, maxlen): #return conversation * words (each conversation has maxlen's words)
		data = self.transform(data)
		for i, conversation in enumerate(data):
			temp = []
			for sentence in conversation:
				temp += sentence

			self.para_maxlen = max(self.para_maxlen, len(temp))
			data[i] = temp

		new_data = np.zeros((len(data), maxlen)).astype(int)
		for i in range(len(data)):
			new_data[i, 0:min(len(data[i]), maxlen)] = data[i][0:min(len(data[i]), maxlen)]

		return new_data[:,:maxlen]

	def get_words(self, index):
		if isinstance(index, list):
			for i in index:
				print i, self.val_dict[i]
		elif isinstance(index, int):
			print i, self.val_dict[index]
		return 

	def load_word2vec_model(self, input_path='/home/wu/data/word2vec/wiki.zh.text.vector', output_path='word2vec'): 
		#load word2vecter model, save word2int dictionary and weight matrix to output_path+_dict.txt and output_path+ljw2v.pkl
		if not input_path:
			print 'path is None'
			return
		with open(input_path) as f:
			nums, ran = f.readline().strip().split()
			embedding_weight = np.zeros((int(nums), int(ran)))
			word_dic = dict()
			for i in range(int(nums)):
				line = f.readline().strip().split()
				word, vec = line[0], line[1:]
				vec = list(map(float, vec))
				self.word_dict[word] = i
				embedding_weight[i, :] = vec
		self.save_dictionary(output_path+'_dict.txt')
		pickle.dump(embedding_weight, open(output_path+'ljw2v.pkl', 'wb'))

	def sentence2vec_sum(self, data):
		return

if __name__ == '__main__':
	positive_data, negtive_data = srt_conv.load_data()
	a = word_dictionary()
	# a.load_word2vec_model()
	a.fit(negtive_data)
	# a.save_dictionary()
	# a = word_dictionary()
	# a.load_dictionary()
	# psdata1 = a.transform(positive_data)
	# print psdata1[:10]
	# positive_data = a.pad_transform(positive_data,100)
	# negtive_data = a.pad_transform(negtive_data,100)
	# print positive_data[:10]
	# print a.para_maxlen
