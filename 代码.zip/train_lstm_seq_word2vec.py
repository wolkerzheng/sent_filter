'''Trains a LSTM on the IMDB sentiment classification task.
The dataset is actually too small for LSTM to be of any advantage
compared to simpler, much faster methods such as TF-IDF + LogReg.
Notes:

- RNNs are tricky. Choice of batch size is important,
choice of loss and optimizer is critical, etc.
Some configurations won't converge.

- LSTM loss decrease patterns during training can be quite different
from what you see with CNNs/MLPs/etc.
'''
import os,time
import pre_srt_conv as srt
import numpy as np
np.random.seed(94) 

import cPickle as pickle
from pre_build_dictionary import word_dictionary
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding, Dropout
from keras.layers import LSTM
from keras.datasets import imdb
from sklearn.cross_validation import train_test_split

print('Loading data...')
positive_data, negtive_data = srt.load_data()

max_features = 30000
maxlen = 80  # cut texts after this number of words (among top max_features most common words)
batch_size = 128

word_dict = word_dictionary()
word_dict.load_dictionary('word2vec_dict.txt')
pkl_file = open('word2vecljw2v.pkl', 'rb')
embedding_weights = pickle.load(pkl_file)

positive_data = word_dict.pad_transform(positive_data,100)
negtive_data = word_dict.pad_transform(negtive_data,100)
x = np.concatenate((positive_data, negtive_data), axis=0)
y = np.concatenate((np.ones((positive_data.shape[0], 1)), np.zeros((negtive_data.shape[0], 1))), axis=0)
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.33, random_state=94)
print positive_data[:2]
print word_dict.para_maxlen
print x.shape
print('Build model...')

model = Sequential()
model.add(Embedding(max_features, 200, mask_zero=True,  weights=[embedding_weights[:max_features]]))
model.add(LSTM(200))
model.add(Dropout(0.2))
model.add(Dense(1, activation='sigmoid'))

# try using different optimizers and different optimizer configs
model.compile(loss='binary_crossentropy',
              optimizer='adam', shuffle=True,
              metrics=['accuracy'])

t1 = time.time()
print('Train...')
model.fit(x_train, y_train,
          batch_size=batch_size,
          epochs=10,
          validation_data=(x_test, y_test))
score, acc = model.evaluate(x_test, y_test,
                            batch_size=batch_size)
print('Test score:', score)
print('Test accuracy:', acc)

t2 = time.time()
print (t2-t1)