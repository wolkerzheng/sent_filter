import time 
import random
import copy
HIGH_LIMIT = 15
LOW_LIMIT = 5
data_path = '/home/wu/data/dgk_shooter_z.conv'

def load_dkg_data():
	data = []
	with open(data_path , 'r') as f1:
		count = 0
		for i, line in enumerate(f1.readlines()):
			tag = line[0]
			raw_line = line[2:].strip()
			if tag == 'E':
				if LOW_LIMIT < count < HIGH_LIMIT:
					data.append(temp)
				temp,count = [], 0
			else:
				temp.append(raw_line)
				count += 1
	return data
def load_negtive_data(data, times=3, random_size=.5):
	# random size todo
	negtive_data = []
	for i in range(times):
		temp_negtive_data = copy.deepcopy(data)
		negtive_data = negtive_data + temp_negtive_data
	for i,conv in enumerate(negtive_data):
		random.shuffle(negtive_data[i])
	return negtive_data

def show_data(data, negtive_data, size):
	random.seed(0)
	for i in range(size):
		random_index = random.randint(0,len(data))
		print 'positive_data:', ' '.join(data[random_index])
		print 'negtive_data:', ' '.join(negtive_data[random_index])
		print ''

def load_data(negtive_times=3, nums=None):
	t_begin = time.time()
	data = load_dkg_data()[:nums]
	negtive_data = load_negtive_data(data, negtive_times)
	t_end = time.time()
	print 'positive_data_shape: ' ,len(data)
	print 'negtive_data_shape: ', len(negtive_data)
	print 'cost time: ', (t_end - t_begin)

	return data,negtive_data

def generate_pair_data():
	t_begin = time.time()
	data = load_dkg_data()
	t_end = time.time()
	print 'cost time: ', (t_end - t_begin)

	return data,negtive_data


# positive_data,negtive_data = load_data(20)
# print len(positive_data)
# show_data(positive_data, negtive_data, 20)